﻿using FluentAssertions;
using System.Net;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using Xunit;

namespace Boticario.CashBack.IntegrationTest.Scenarios
{
    public class LogTest
    {
        private static string token;
        
        public async Task<string> GetToken(TestProvider testServer)
        {
            if (token == null)
                token = await testServer.GetToken("admin@boticario.com.br", "password");
            return await Task<string>.FromResult(token);
        }

        [Fact]
        public async Task GetLogsTest()
        {
            using (var server = new TestProvider())
            using (var client = server.Client)
            {
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", await GetToken(server));
                var responseMessage = await client.GetAsync("/api/Log");
                responseMessage.StatusCode.Should().Be(HttpStatusCode.OK);
            }
        }
    }
}

