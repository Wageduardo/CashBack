﻿using Boticario.CashBack.Api;
using Boticario.CashBack.Models.ViewModel;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.TestHost;
using Newtonsoft.Json;
using System;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace Boticario.CashBack.IntegrationTest
{
    public static class LockCreate
    {
        public static object Lock = new object();
    }

    public class TestProvider : IDisposable
    {
        private readonly TestServer server;
        public HttpClient Client { get; private set; }
        

        public TestProvider()
        {
            lock (LockCreate.Lock)
            {
                server = new TestServer(new WebHostBuilder().UseStartup<Startup>());
                Client = server.CreateClient();
            }
        }

        public async Task<string> GetToken(string email, string password)
        {
            using (var client = new TestProvider().Client)
            {
                var authModel = new AuthModel
                {
                    Email = email,
                    Password = password
                };

                var jsonContent = JsonConvert.SerializeObject(authModel);
                var contentString = new StringContent(jsonContent, Encoding.UTF8, "application/json");
                contentString.Headers.ContentType = new
                MediaTypeHeaderValue("application/json");

                var response = await client.PostAsync("/api/Auth", contentString);
                response.EnsureSuccessStatusCode();
                var responseString = await response.Content.ReadAsStringAsync();
                dynamic item = JsonConvert.DeserializeObject<object>(responseString);        
                return item["token"];
            }
        }

        public void Dispose()
        {
            server?.Dispose();
            Client?.Dispose();
        }
    }
}
