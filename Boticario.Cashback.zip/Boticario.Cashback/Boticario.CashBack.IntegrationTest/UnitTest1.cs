using System;
using Xunit;

namespace Cashback.IntegrationTest
{
    public class UnitTest1
    {
        [Fact]
        public void Test1()
        {

        }
    }
}
