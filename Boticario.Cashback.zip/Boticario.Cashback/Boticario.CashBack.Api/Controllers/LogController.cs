﻿// ----------------------------------------
// <copyright file=LogController.cs company=Boticario>
// Copyright (c) [Boticario] [2020]. Confidential.  All Rights Reserved
// </copyright>
// ----------------------------------------
using Boticario.CashBack.Core.SecurityRoles;
using Boticario.CashBack.Repositories.Database;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System;
using System.Threading.Tasks;

namespace Boticario.CashBack.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class LogController : ControllerBase
    {
        private readonly ILogger<LogController> logger;

        public LogController(ILogger<LogController> logger)
        {
            this.logger = logger;
        }

        [HttpGet]
        [Authorize(Policies.Administrator)]
        public async Task<IActionResult> Get([FromServices]LogContext logContext)
        {
            try
            {
                return Ok(await logContext.Logs?.ToListAsync());
            }
            catch (Exception ex)
            {
                logger.LogError(ex.Message);
                return BadRequest(ex);
            }
        }
    }
}
