﻿// ----------------------------------------
// <copyright file=IUser.cs company=Boticario>
// Copyright (c) [Boticario] [2020]. Confidential.  All Rights Reserved
// </copyright>
// ----------------------------------------
namespace Boticario.CashBack.Interfaces.Models
{
    public interface IUser : IEntityBase
    {
        string Cpf { get; set; }
        string Email { get; set; }
        string Name { get; set; }
        string Password { get; set; }
        string Role { get; set; }

        string ToString();
    }
}