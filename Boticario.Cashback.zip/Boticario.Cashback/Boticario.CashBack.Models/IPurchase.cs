﻿// ----------------------------------------
// <copyright file=IPurchase.cs company=Boticario>
// Copyright (c) [Boticario] [2020]. Confidential.  All Rights Reserved
// </copyright>
// ----------------------------------------
using Boticario.CashBack.Models.Interfaces.Enums;

namespace Boticario.CashBack.Interfaces.Models
{
    public interface IPurchase : IEntityBase
    {
        double? CashbackPercent { get; set; }
        double? CashbackValue { get; set; }
        string Code { get; set; }
        string Cpf { get; set; }
        string Email { get; set; }
        ECashbackStatus Status { get; set; }
        double Value { get; set; }

        string ToString();
    }
}