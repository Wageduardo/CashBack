﻿namespace Boticario.CashBack.Models.ViewModel
{
    /// <summary>
    /// External model
    /// </summary>
    public class ExternalViewModel
    {
        /// <summary>
        /// Gets or sets the status code.
        /// </summary>
        /// <value>
        /// The status code.
        /// </value>
        public int StatusCode { get; set; }
        /// <summary>
        /// Gets or sets the body.
        /// </summary>
        /// <value>
        /// The body.
        /// </value>
        public Body Body { get; set; }
    }

    /// <summary>
    /// Body to External model
    /// </summary>
    public class Body
    {
        /// <summary>
        /// Gets or sets the credit.
        /// </summary>
        /// <value>
        /// The credit.
        /// </value>
        public decimal Credit { get; set; }
    }
}
