﻿using System;

namespace Boticario.CashBack.Models.ViewModel
{
    public class AuthResponse
    {
        #region [ Public methods ]

        public Guid Id { get; }
        public string Email { get; }
        public string Cpf { get; }
        public string Role { get; }
        public string Name { get; }
        public string Token { get; }

        #endregion [ Public methods ]

        #region [ Constructors ]

        public AuthResponse()
        {
        }

        public AuthResponse(User user, string token)
        {
            Id = user.Id;
            Name = user.Name;
            Cpf = user.Cpf;
            Email = user.Email;
            Role = user.Role;
            Token = token;
        } 

        #endregion [ Constructors ]
    }
}
