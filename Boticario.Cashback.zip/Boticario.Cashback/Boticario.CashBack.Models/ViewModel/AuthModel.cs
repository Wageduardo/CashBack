﻿// ----------------------------------------
// <copyright file=AuthModel.cs company=Boticario>
// Copyright (c) [Boticario] [2020]. Confidential.  All Rights Reserved
// </copyright>
// ----------------------------------------
using System.ComponentModel.DataAnnotations;

namespace Boticario.CashBack.Models.ViewModel
{
    public class AuthModel
    {
        [Required(AllowEmptyStrings = false, ErrorMessage = "You must enter the E-mail"), EmailAddress(ErrorMessage = "Email is not valid.")]
        public string Email { get; set; }
        [Required(AllowEmptyStrings = false, ErrorMessage = "You must enter the Password")]
        public string Password { get; set; }
    }
}
