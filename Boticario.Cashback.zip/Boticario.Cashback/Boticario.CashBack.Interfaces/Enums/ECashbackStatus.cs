﻿// ----------------------------------------
// <copyright file=ECashbackStatus.cs company=Boticario>
// Copyright (c) [Boticario] [2020]. Confidential.  All Rights Reserved
// </copyright>
// ----------------------------------------
namespace Boticario.CashBack.Models.Interfaces.Enums
{
    public enum ECashbackStatus
    {
        OnCheking,
        Approved,
        Unapproved
    }
}
