﻿// ----------------------------------------
// <copyright file=PurchaseRepository.cs company=Boticario>
// Copyright (c) [Boticario] [2020]. Confidential.  All Rights Reserved
// </copyright>
// ----------------------------------------
using Boticario.CashBack.Models;
using Boticario.CashBack.Repositories.Database;

namespace Boticario.CashBack.Repositories
{
    public class PurchaseRepository : Repository<Purchase>, IPurchaseRepository
    {
        public PurchaseRepository(BoticarioContext context) : base(context)
        {
        }
    }
}
