﻿// ----------------------------------------
// <copyright file=UserRepository.cs company=Boticario>
// Copyright (c) [Boticario] [2020]. Confidential.  All Rights Reserved
// </copyright>
// ----------------------------------------
using Boticario.CashBack.Models;
using Boticario.CashBack.Repositories.Database;

namespace Boticario.CashBack.Repositories
{
    public class UserRepository : Repository<User>, IUserRepository
    {
        public UserRepository(BoticarioContext context) : base(context)
        {
        }
    }
}
