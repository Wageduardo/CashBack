﻿using Boticario.CashBack.Models;
using Boticario.CashBack.Tests.Extensions;
using Microsoft.EntityFrameworkCore;
using NUnit.Framework;
using System;
using System.Diagnostics.CodeAnalysis;
using System.IO;

namespace Boticario.CashBack.Repositories.Database.Tests
{
    [TestFixture()]
    [ExcludeFromCodeCoverage]
    public class LogContextTests
    {
        LogContext context;
        string file = Guid.NewGuid().ToString();

        [SetUp()]
        public void Initiliaze()
        {
            var options = new DbContextOptionsBuilder<LogContext>()
                .UseSqlite($"Data Source = {file}.db")
                .Options;



            context = new LogContext(options);

            var log = new Log();
            log.SetAllProperties();
            log.GetPropertyValues();
            log.ToString();
        }

        [TearDown()]
        public void TearDown()
        {
            var db = context.Database;
            context.Dispose();
            db.EnsureDeleted();
        }

        [Test()]
        public void CreateDataBaseTest()
        {
            context.CreateDataBase();
            Assert.IsTrue(File.Exists($"{file}.db"));
        }
    }
}