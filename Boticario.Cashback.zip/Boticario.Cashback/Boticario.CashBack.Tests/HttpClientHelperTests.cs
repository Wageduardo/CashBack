﻿using Boticario.CashBack.Core;
using Boticario.CashBack.Models.ViewModel;
using Microsoft.Extensions.Logging;
using Moq;
using NUnit.Framework;
using System.Diagnostics.CodeAnalysis;
using System.Net.Http;
using System.Threading.Tasks;

namespace Boticario.CashBack.Services.Tests
{
    [TestFixture()]
    [ExcludeFromCodeCoverage]
    public class HttpClientHelperTests
    {
        Mock<ILogger<HttpClientHelper>> logger;
        IHttpClientHelper httpClientHelper;

        [SetUp]
        public void Init()
        {
            logger = new Mock<ILogger<HttpClientHelper>>();
            httpClientHelper = new HttpClientHelper(logger.Object);
        }


        [Test()]
        public async Task  SendGetAsyncTest()
        {
            string cpf = "123";
            string baseUrl = $"{AppConfig.ExternalUrl}v1/cashback?cpf={cpf}";
            var a = await httpClientHelper.SendGetAsync<ExternalViewModel>(baseUrl, AppConfig.ExternalToken);
            Assert.That(a, Is.Not.Null);
            Assert.That(a.StatusCode, Is.EqualTo(200));
        }

        [Test()]
        public async Task SendGetAsyncTestFails()
        {
            string cpf = "123";
            string baseUrl = $"{AppConfig.ExternalUrl}v1?cpf={cpf}";
            Assert.ThrowsAsync<HttpRequestException>(() => httpClientHelper.SendGetAsync<ExternalViewModel>(baseUrl, "123"));
        }
    }
}