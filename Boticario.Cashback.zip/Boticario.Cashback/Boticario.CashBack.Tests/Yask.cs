﻿namespace Boticario.CashBack.Services.Tests
{
    public class Yask
    {
    }
}