﻿// ----------------------------------------
// <copyright file=IPurchaseService.cs company=Boticario>
// Copyright (c) [Boticario] [2020]. Confidential.  All Rights Reserved
// </copyright>
// ----------------------------------------
using Boticario.CashBack.Models;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace Boticario.CashBack.Services
{
    public interface IPurchaseService
    {
        Task<Purchase> CreatePurchase(Purchase purchase, User user);
        Task<int> DeletePurchase(Purchase purchase);
        Task<List<Purchase>> GetAll();
        Task<double> GetCashback(Expression<Func<User, bool>> match);
        Task<double> GetCaskbackPercent(double value);
        Task<Purchase> GetPurchase(Guid id);
        Task<List<Purchase>> GetUserPurchases(Expression<Func<User, bool>> match);
        Task<Purchase> UpdatePurchase(Purchase purchase, User user);
        void ValidateMandatoryFields(Purchase purchase, User user);
    }
}