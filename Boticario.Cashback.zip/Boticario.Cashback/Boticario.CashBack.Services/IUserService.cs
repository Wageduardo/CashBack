﻿// ----------------------------------------
// <copyright file=IUserService.cs company=Boticario>
// Copyright (c) [Boticario] [2020]. Confidential.  All Rights Reserved
// </copyright>
// ----------------------------------------
using Boticario.CashBack.Models;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace Boticario.CashBack.Services
{
    public interface IUserService
    {
        Task<(User user, string token)> Authenticate(string email, string password);
        Task<User> CreateUser(User user);
        Task<User> DeleteUser(User user);
        Task<User> UpdateUser(User user);
        Task<List<User>> GetAll();
        Task<User> GetUser(Guid id);
        Task<User> GetUserByEmail(string email, bool validate = true);
        void ValideteUserData(User user);
        Task<User> FindUser(Expression<Func<User, bool>> match);
    }
}