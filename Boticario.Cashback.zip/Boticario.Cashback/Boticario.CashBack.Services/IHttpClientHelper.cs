﻿using System.Threading.Tasks;

namespace Boticario.CashBack.Services
{
    public interface IHttpClientHelper
    {
        Task<TResult> SendGetAsync<TResult>(string url, string token);
    }
}
