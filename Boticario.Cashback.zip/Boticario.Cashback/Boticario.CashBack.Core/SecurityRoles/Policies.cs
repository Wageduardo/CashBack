﻿// ----------------------------------------
// <copyright file=Policies.cs company=Boticario>
// Copyright (c) [Boticario] [2020]. Confidential.  All Rights Reserved
// </copyright>
// ----------------------------------------
namespace Boticario.CashBack.Core.SecurityRoles
{
    public static class Policies
    {
        public const string All = "All";
        public const string User = "User";
        public const string Administrator = "Administrator";
    }
}
